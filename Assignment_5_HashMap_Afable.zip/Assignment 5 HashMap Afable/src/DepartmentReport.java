public class DepartmentReport {
    DepartmentReport() {
        DepartmentDA departmentDA = new DepartmentDA();
    }

    public static void main(String[] args) {
        new DepartmentDA();
    }
}
